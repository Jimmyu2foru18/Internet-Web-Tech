<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>URLs Submission Form</title>
    <meta name="author" content="James McGuigan">
</head>

<body>

<?php
$hostname = "localhost";
$username = "root";
$password = "111111";
$database = "URLs";

$conn = mysqli_connect($hostname, $username, $password, $database);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if(isset($_POST["URLs"]) && isset($_POST["des"])) {
    $URLs = mysqli_real_escape_string($conn, $_POST["URLs"]);
    $desc = mysqli_real_escape_string($conn, $_POST["des"]);

    $sql = "INSERT INTO urltable (URLs, descrip) VALUES ('$URLs', '$desc')";
    if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
    }
}

$query = "SELECT * FROM urltable";
$result = mysqli_query($conn, $query);
if (mysqli_num_rows($result) > 0) 
{
    echo "<table border='1' cellspacing='4' cellpadding='4'>
            <tr>
                <th>URLs</th>
                <th>Description</th>
            </tr>";
    while ($row = mysqli_fetch_assoc($result)) 
	{
        echo "<tr>
                <td><font face='Arial, sans-serif'>" . $row["URLs"] . "</font></td>
                <td><font face='Arial, sans-serif'>" . $row["descrip"] . "</font></td>
              </tr>";
    }
    echo "</table>";
}

mysqli_close($conn);
?>

<div>
    <form name="subm" action="test.php" method="POST">
        <label for="URLs">URLs:</label>
        <input type="text" name="URLs" />
        <label for="des">Description:</label>
        <input type="text" name="des" />
        <input type="submit" />
    </form>
</div>

</body>
</html>
