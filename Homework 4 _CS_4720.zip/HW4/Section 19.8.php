<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PHP Email Address</title>
    <meta name="author" content="James McGuigan">
</head>
<body>
    <h1>PHP Email Address</h1>
    
    <form action="" method="post">
        Email:
        <input type="text" name="email">
        <input type="submit" value="Validate" name="submit">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") 
	{
        if (isset($_POST['submit'])) 
		{
            $mail = $_POST['email'];

            if (filter_var($mail, FILTER_VALIDATE_EMAIL)) 
			{
                echo("$mail is a valid email address");
            } 
			else 
			{
                echo("$mail is not a valid email address");
            }
        }
    }
    ?>
</body>
</html>
