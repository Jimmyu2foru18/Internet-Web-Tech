<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>PHP States</title>
    <meta name="author" content="James McGuigan">
</head>

<body>
    <h1>PHP States</h1>
    
    <?php
    $states = "Mississippi Alabama Texas Massachusetts Kansas";

    $statesArray = [];
    $states1 = explode(" ", $states);

    foreach ($states1 as $state) 
	{
        if (preg_match('/xas$/', $state)) 
		{
            $statesArray[] = $state;
        }
    }
    foreach ($states1 as $state) {
        if (preg_match('/^k.*s$/i', $state)) 
		{
            $statesArray[] = $state;
        }
    }
    foreach ($states1 as $state) {
        if (preg_match('/^M.*s$/', $state)) 
		{
            $statesArray[] = $state;
        }
    }
    foreach ($states1 as $state) {
        if (preg_match('/a$/', $state)) 
		{
            $statesArray[] = $state;
        }
    }
    if (preg_match('/^M.*$/', $states1[0])) 
	{
        $statesArray[] = $states1[0];
    }


    foreach ($statesArray as $state) 
	{
        echo $state . "<br>";
    }
    ?>
	
</body>
</html>


